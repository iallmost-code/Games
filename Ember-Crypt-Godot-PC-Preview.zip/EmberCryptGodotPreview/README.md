# Ember Crypt · Godot PC Preview

A self-contained, playable **2D Godot project with an angled 2.5D presentation**. This lets you judge the existing Ember Crypt art in Godot before deciding whether to port the full game. It uses existing art and samples from your Games repository plus original GDScript and a procedural Ash ambient bed. No plugins, C#, internet connection at runtime, or additional asset downloads are required.

## Open it

Use **Godot 4.6 or newer, Standard edition**; tested with Godot 4.6.3. Extract the ZIP, use the Project Manager's **Import** button to select `project.godot`, choose **Import & Edit**, wait for asset import, and press **F5**. The scene is assembled at runtime, so the editor canvas is initially empty. `scenes/preview.tscn` is the configured main scene.

Godot itself is not included. An exported Windows executable is not included; this is the project you asked to open in Godot. Export templates are only necessary if you later choose to build a standalone executable.

## What you can try

- Bloodknight's existing authored six-frame front/side/back walks and attack, three-frame hit and death poses, with normalized foot anchors. A PNG fallback source is included beside the WebP atlas.
- A connected Ash dungeon: three combat rooms, two side rooms, corridors and a locked boss chamber. Stone tiles, raised wall faces/platform edges, existing braziers, pillars, coffins, bones, chains and statue art, decorative lower lava seams and embers.
- Native `AnimatedSprite2D` animation, `Camera2D` follow, depth-sorted upright actors/props/walls, soft native `PointLight2D` lighting and pillar shadow occluders. Foreground masonry fades near the hero.
- Automatic 150-degree blade arcs, approximately 95px reach, 0.55-second interval, 58 base damage, 140 HP, 45 armor and 207 world-units/s movement. Nearby foes are aimed at even while moving. Wall checks protect targets.
- Skeleton/ghoul/runner encounters, bounded room-edge arrivals with one-second warning, damage flashes, pop-up damage numbers, ground shadows, a readable hero ring and enemy HP bars.
- Dash: movement/facing direction, 0.25-second invulnerability and four-second cooldown. Earthsplitter: nearby slam damage and a two-second stun; starts ready for demonstration and subsequently charges from damage/kills.
- A Crypt Warden encounter with marked slam warning, boss bar, unlocked stairs and a finish screen. Gate opens after 12 kills **or 45 seconds for this preview**, not the production game's three-minute threshold.
- Bronze/dark HUD, minimap, controls legend, pause/resume, restart, fullscreen, mute, looping Ash ambience and sampled combat audio with eight bounded voices and a master compressor.

## Controls

| Key | Action |
|---|---|
| WASD / arrows | Move in screen directions |
| Space | Dash |
| E | Earthsplitter |
| Escape | Pause / resume |
| R | Restart |
| M | Sound on/off |
| F11 | Fullscreen / windowed |

Attacks stay automatic. There are no new during-play mouse buttons. This is a **keyboard PC preview**; the touch joystick and mobile exports have not been ported.

## Scope and differences

This is an evaluation slice rather than a production conversion. It does **not** include the other heroes, full AI/pathfinding, XP/cards/evolutions, relics, loot progression, ten floors, Torment/Endless/daily, achievements/mastery, slot persistence or EC1 import. Enemy tuning, boss HP, ultimate charge and encounter timing are simplified for a short demo, so this is **not a balance-equivalent copy** of the browser game. Props, lava seams and lighting are decorative; the stone occupancy grid is the source of truth for collision. The current browser project and its saves are never accessed or modified by the prototype.

## How the project is organized

- `scripts/preview.gd`: Cartesian gameplay, collision/LOS substeps, automatic attacks, skills, encounters, native lights/audio and game flow.
- `scripts/environment.gd`: projected dungeon floor, raised edges, lower lava decoration, blade/slam/danger effects and bounded embers.
- `scripts/avatar.gd`: grounded native sprite animation and cosmetic movement/hit visuals.
- `scripts/wall.gd`: raised wall faces and foreground fading.
- `scripts/hud.gd`: PC HUD, minimap and pause/finish overlays.
- `assets/hero/bloodknight.tres`: six-animation native SpriteFrames resource with WebP atlas regions; `bloodknight-frames.png` is the fallback source.
- `assets/ASSET-PROVENANCE.json`: repository and source commit used for existing art/audio.
- `PREVIEW.png` / `BOSS-PREVIEW.png`: screenshots captured from the actual Godot Compatibility renderer, not generated concept art.

## Validation

`tests/smoke.gd` runs 31 Godot integration assertions: map connectivity, gate lock/unlock, projection roundtrips, melee aiming/range/walls, anti-tunnelling movement, Dash invulnerability/cooldown, Ultimate damage/stun/charge, boss spawn/death/stairs, restart, immediate game-over, pause/resume, bounded audio, depth sorting and authored animation counts. Run it with:

```
godot --headless --path . --script res://tests/smoke.gd
```

The project was also launched and rendered with Godot 4.6.3's native OpenGL Compatibility renderer at 1280×720 on a Linux software-rendered display. Windows hardware performance has not been measured. The engine is capped at 60 FPS; this is a target, not a physical-device performance claim. A clean extraction is reimported and tested before delivery. Validation results are in `tests/validation.json` and `tests/PACKAGE-VALIDATION.json`.

The ZIP omits machine-specific `.godot` caches: Godot regenerates these on first import. All project dependencies, original asset crops, scripts and scene/resource files are included.
